#!/bin/sh

docker compose exec airgap bash
