#!/bin/sh

docker compose down
