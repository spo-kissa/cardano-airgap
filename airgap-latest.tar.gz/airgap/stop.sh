#!/bin/sh

docker compose stop
