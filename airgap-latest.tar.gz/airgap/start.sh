#!/bin/sh

docker compose up -d
